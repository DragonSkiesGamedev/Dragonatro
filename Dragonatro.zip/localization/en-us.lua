return {
	descriptions = {
		Joker = {
			j_sock_and_buskin = {
				name = "Smaug and Buskin",
			},
		},
	},
}
